const config = {
    MODE: 'ouat',
    OC_URL: 'https://script.google.com/macros/s/AKfycbw8AVM4-hdDgdzTGPCoRQ_L4hOjanZqCN2wDZLi1-kH7pflBXd9DbjCapgDzn8syZHlIg/exec',
    ADD_URL: 'https://script.google.com/macros/s/AKfycbyIUY096UOuZ42TbJzwffdli3QVS1yIhWKvFe-HrOBWJRpD_LeFZt3mn4ahfNsArhh7/exec',
    DISC_URL: 'https://script.google.com/macros/s/AKfycbyIUY096UOuZ42TbJzwffdli3QVS1yIhWKvFe-HrOBWJRpD_LeFZt3mn4ahfNsArhh7/exec',
    SHEET_ID: '10126847',
    SPREAD_SHEETS_ID: '1m56QTu-G-Pf63wkSNmAcFdLiWdW9eF7kzf-H-Q2d2So',
    GUILD_NAME: 'Once Upon a Time',
    T8_TAG_ID: '1290981353143271494',
    T9_TAG_ID: '1363061647635124335',
    FULL_TAG_ID: '1332344859683459193',
    MSG_CHANNEL_ID: '1292335759717564466',
};

module.exports = config;