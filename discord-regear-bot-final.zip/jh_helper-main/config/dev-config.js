const config = {
    MODE: 'dev',
    OC_URL: 'https://script.google.com/macros/s/AKfycbw8AVM4-hdDgdzTGPCoRQ_L4hOjanZqCN2wDZLi1-kH7pflBXd9DbjCapgDzn8syZHlIg/exec',
    ADD_URL: 'https://script.google.com/macros/s/AKfycbyIUY096UOuZ42TbJzwffdli3QVS1yIhWKvFe-HrOBWJRpD_LeFZt3mn4ahfNsArhh7/exec',
    DISC_URL: 'https://script.google.com/macros/s/AKfycbxEwEUvD0X6ntSEQRAnR8XLD1FhplCgwN_x59AJIF5UsP9FWJUTUaXlbQZnZOFhShWacw/exec',
    GUILD_NAME: 'Once Upon a Time',
    SHEET_ID: '10126847',
    SPREAD_SHEETS_ID: '1m56QTu-G-Pf63wkSNmAcFdLiWdW9eF7kzf-H-Q2d2So',
    GUILD_NAME: 'Once Upon a Time',
    T8_TAG_ID: '1332344637972680714',
    T9_TAG_ID: '1332344706717188147',
    FULL_TAG_ID: '1332344859683459193',
    MSG_CHANNEL_ID:'1010966927130251264',
};

module.exports = config;