const config = {
    MODE: 'vlrus',
    OC_URL: 'https://script.google.com/macros/s/AKfycbyQ_e78UYgPNl29uUTS7Q5IKKN_wnnuWNnTacSjPsWNaSEZZDy1oTTCgS0MCEwjuskuoQ/exec',
    ADD_URL: 'https://script.google.com/macros/s/AKfycbzRBNAE2i-KWUfa1LDO7qpeLlMchD74CMMQhRixO7K2rjPuf0hF1d7eP6WUK1xe2QgYkA/exec',
    DISC_URL: 'https://script.google.com/macros/s/AKfycbxEwEUvD0X6ntSEQRAnR8XLD1FhplCgwN_x59AJIF5UsP9FWJUTUaXlbQZnZOFhShWacw/exec',
    SHEET_ID: '10126847',
    // 與OUTA使用同一個來源 可以不用改兩次
    SPREAD_SHEETS_ID: '1m56QTu-G-Pf63wkSNmAcFdLiWdW9eF7kzf-H-Q2d2So',
    GUILD_NAME: 'VlRUS',
    T8_TAG_ID: '1332344637972680714',
    T9_TAG_ID: '1332344706717188147',
    FULL_TAG_ID: '1332344859683459193',
    MSG_CHANNEL_ID:'1332828537102794954',
    
};

module.exports = config;