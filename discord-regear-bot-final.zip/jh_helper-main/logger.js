const pino = require('pino');
const logger = pino();
module.exports = logger;